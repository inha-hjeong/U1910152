# Speed Test Mobile App UI Design in Jetpack Compose


Internet Speed Test Android App designed using Jetpack Compose. The single-screen design shows an animated app checking internet speed.

### Preview

![App UI](screenshots/screenshot.png)

